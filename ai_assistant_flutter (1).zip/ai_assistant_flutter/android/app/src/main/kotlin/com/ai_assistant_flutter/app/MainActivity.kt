package com.ai_assistant_flutter.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
